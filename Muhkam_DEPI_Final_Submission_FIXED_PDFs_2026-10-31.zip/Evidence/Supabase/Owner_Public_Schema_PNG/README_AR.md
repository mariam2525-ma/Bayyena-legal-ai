# صورتا مخطط Supabase (public) — زوّدت بهما المالكة

- `public_schema_view_2_top_tables.png`: يظهر فيها كاملًا جدول `bayyena_knowledge` (14 عمودًا) وجداول `history` و`review_jobs`، وبداية `support_tickets`.
- `public_schema_view_1_bottom_tables.png`: يظهر فيها `history` و`review_jobs` و`support_tickets` كاملة بأعمدتها، وأسفل `bayyena_knowledge`.
- في كلتا الصورتين: العلاقة من `history.user_id` و`review_jobs.user_id` و`support_tickets.user_id` إلى `auth.users.id`.
- الصور أصلية دون تعديل (SHA-256 في MANIFEST.sha256).

## الحالة (7b)
الجداول العامة الأربعة وأعمدتها وأنواعها وعلاقاتها مع `auth.users` ظاهرة الآن عبر الصورتين معًا. ومع ذلك:
- لا توجد صورة واحدة كاملة؛ كل صورة تقطع جزءًا من الجداول وتتداخل بطاقتا `bayyena_knowledge` و`history` بصريًا.
- الرسم لا يثبت DDL كاملًا ولا ON DELETE ولا defaults ولا الفهارس ولا RLS ولا grants ولا الدوال ولا بُعد vector ولا سلوك RLS وقت التشغيل.
- لذلك تُسجَّل 7b بأنها: **جزئي — مقوّى** (ليست مستوفاة بالكامل). للاستيفاء: تصدير واحد للـ public بعد Fit view.
