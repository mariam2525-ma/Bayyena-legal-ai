-- شغّل هذا الملف مرة واحدة في Supabase → SQL Editor
create extension if not exists vector;

-- 1) سجل كل مستخدم (يراه صاحبه فقط بفضل RLS)
create table if not exists public.history (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind       text not null check (kind in ('review','draft','research','chat')),
  title      text,
  input      jsonb,
  output     text,
  created_at timestamptz not null default now()
);
create index if not exists history_user_idx on public.history (user_id, created_at desc);
alter table public.history enable row level security;
revoke all on public.history from anon;
grant select, insert, delete on public.history to authenticated;
drop policy if exists "history_select_own" on public.history;
drop policy if exists "history_insert_own" on public.history;
drop policy if exists "history_delete_own" on public.history;
create policy "history_select_own" on public.history for select to authenticated using (user_id = auth.uid());
create policy "history_insert_own" on public.history for insert to authenticated with check (user_id = auth.uid());
create policy "history_delete_own" on public.history for delete to authenticated using (user_id = auth.uid());

-- 2) حماية قاعدة المعرفة: المفتاح العام (anon) لا يجب أن يقرأها أو يكتب فيها.
--    n8n يستخدم service_role فيتجاوز RLS ويعمل كما هو.
alter table public.bayyena_knowledge enable row level security;
revoke all on public.bayyena_knowledge from anon, authenticated;

-- 3) دالة البحث الدلالي التي يستدعيها Workflow 5
--    (لو أنواع أعمدة الجدول عندك مختلفة عدّل الـ casts)
create index if not exists bayyena_knowledge_emb_idx
  on public.bayyena_knowledge using hnsw (embedding vector_cosine_ops);

create or replace function public.match_bayyena_knowledge(
  query_embedding vector(1536), match_count int default 6, min_similarity float default 0.5)
returns table (chunk_id text, title text, document_type text, content text, similarity float)
language sql stable as $$
  select k.chunk_id::text, k.title::text, k.document_type::text, k.content::text,
         (1 - (k.embedding <=> query_embedding))::float
  from public.bayyena_knowledge k
  where 1 - (k.embedding <=> query_embedding) >= min_similarity
  order by k.embedding <=> query_embedding
  limit least(match_count, 12)
$$;
revoke all on function public.match_bayyena_knowledge(vector, int, float) from public, anon, authenticated;
grant execute on function public.match_bayyena_knowledge(vector, int, float) to service_role;
