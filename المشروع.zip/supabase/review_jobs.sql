-- جدول المهام غير المتزامنة (Async) — مستنتج من كود الموقع: الموقع يُدرج {id,status:'pending'} ثم يقرأ (status,report,error).
-- التحديث النهائي للحالة يتم فقط عبر الدالة finish_review_job أدناه (لا UPDATE مباشر للمستخدم).
create table if not exists public.review_jobs (
  id         uuid primary key,
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  status     text not null default 'pending' check (status in ('pending','done','error')),
  report     text,
  error      text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists review_jobs_user_idx on public.review_jobs (user_id, created_at desc);
alter table public.review_jobs enable row level security;
revoke all on public.review_jobs from anon;
grant select, insert on public.review_jobs to authenticated;
drop policy if exists "jobs_select_own" on public.review_jobs;
drop policy if exists "jobs_insert_own" on public.review_jobs;
create policy "jobs_select_own" on public.review_jobs for select to authenticated using (user_id = auth.uid());
-- المستخدم يستطيع إنشاء مهمة pending فقط؛ لا يستطيع كتابة تقرير أو تغيير الحالة (يمنع تزوير النتائج)
create policy "jobs_insert_own" on public.review_jobs for insert to authenticated
  with check (user_id = auth.uid() and status = 'pending' and report is null and error is null);

-- ===== مسار تحديث آمن للمهمة (بديل PATCH المباشر) =====
-- n8n يستدعي: POST /rest/v1/rpc/finish_review_job بنفس توكن المستخدم.
-- الدالة: تتحقق أن المهمة ملك المستدعي، وأنها ما زالت pending، وتقبل done/error فقط، ولمرة واحدة.
-- لا يوجد grant أو policy من نوع UPDATE على الجدول، فلا يستطيع أحد تعديل مهام غيره أو إعادة فتح مهمة منتهية.
create or replace function public.finish_review_job(
  p_id uuid, p_status text, p_report text default null, p_error text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  if p_status not in ('done','error') then
    raise exception 'invalid status' using errcode = '22023';
  end if;
  update public.review_jobs
     set status     = p_status,
         report     = case when p_status = 'done'  then left(p_report, 500000) else null end,
         error      = case when p_status = 'error' then left(coalesce(p_error,'error'), 500) else null end,
         updated_at = now()
   where id = p_id and user_id = auth.uid() and status = 'pending';
  if not found then
    raise exception 'job not found or already finished' using errcode = 'P0002';
  end if;
end $$;
revoke all on function public.finish_review_job(uuid,text,text,text) from public, anon;
grant execute on function public.finish_review_job(uuid,text,text,text) to authenticated;
